var locations=[
['Apollo 11', 
'0.67408', 
'23.473', 
'Apolo 11 fue una misión espacial tripulada de Estados Unidos cuyo objetivo fue lograr que un ser humano caminara en la superficie de la Luna. La misión se envió al espacio el 16 de julio de 1969, llegó a la superficie de la Luna el 20 de julio de ese mismo año y al día siguiente logró que 2 astronautas (Armstrong y Aldrin) caminaran sobre la superficie lunar. El Apolo 11 fue impulsado por un cohete Saturno V desde la plataforma LC 39A y lanzado a las 13:32 hora local del complejo de Cabo Kennedy, en Florida (EE.UU.). Oficialmente se conoció a la misión como AS-506. La misión está considerada como uno de los momentos más significativos de la historia de la Humanidad y la Tecnología.'
],
['Apollo 12', 
'-3.01239', 
'-23.4216', 
'Apolo 12 fue la sexta misión tripulada del programa Apolo de la NASA, y la segunda que alunizó. Lanzada unos meses después del Apolo 11, el Apolo 12 alunizó en el Oceanus Procellarum, muy cerca de la sonda estadounidense Surveyor 3, posada en la Luna desde abril de 1967, y los astronautas trajeron algunas piezas de esta sonda de vuelta a la Tierra para su estudio, entre ellas la cámara fotográfica.'
],
['Apollo 13', 
'0', 
'0', 
'Apolo 11 fue una misión espacial tripulada de Estados Unidos cuyo objetivo fue lograr que un ser humano caminara en la superficie de la Luna. La misión se envió al espacio el 16 de julio de 1969, llegó a la superficie de la Luna el 20 de julio de ese mismo año y al día siguiente logró que 2 astronautas (Armstrong y Aldrin) caminaran sobre la superficie lunar. El Apolo 11 fue impulsado por un cohete Saturno V desde la plataforma LC 39A y lanzado a las 13:32 hora local del complejo de Cabo Kennedy, en Florida (EE.UU.). Oficialmente se conoció a la misión como AS-506. La misión está considerada como uno de los momentos más significativos de la historia de la Humanidad y la Tecnología.'
],
['Apollo 14', 
'-3.6453', 
'-17.4714', 
'Apolo 11 fue una misión espacial tripulada de Estados Unidos cuyo objetivo fue lograr que un ser humano caminara en la superficie de la Luna. La misión se envió al espacio el 16 de julio de 1969, llegó a la superficie de la Luna el 20 de julio de ese mismo año y al día siguiente logró que 2 astronautas (Armstrong y Aldrin) caminaran sobre la superficie lunar. El Apolo 11 fue impulsado por un cohete Saturno V desde la plataforma LC 39A y lanzado a las 13:32 hora local del complejo de Cabo Kennedy, en Florida (EE.UU.). Oficialmente se conoció a la misión como AS-506. La misión está considerada como uno de los momentos más significativos de la historia de la Humanidad y la Tecnología.'
],
['Apollo 15', 
'26.1322', 
'3.63386', 
'Decimoquinto vuelo del programa Apolo (denominado oficialmente AS-510), fue lanzado el 26 de julio de 1971 mediante un cohete del tipo Saturno 5, en dirección a la Luna.Fue la primera de las misiones del tipo J, es decir, con modificaciones en la astronave que permitía una duración del vuelo de hasta 14 días.Poco después de comenzar la órbita lunar número 12, el módulo de descenso consiguió alunizar a 26,08º N 3,66º E (a sólo un centenar de metros del punto teórico en la región de Hadley-Apeninos, en el Mare Imbrium) llevando como tripulantes a David R. Scott -comandante-, Alfred M. Worden y James B. Irwin.'
],
];
